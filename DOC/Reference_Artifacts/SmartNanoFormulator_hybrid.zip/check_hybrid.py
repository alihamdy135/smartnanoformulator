"""Check real model integration and routing, including simulated conflicting evidence."""
import json
from pathlib import Path
from hybrid import Hybrid, decide

root = Path(__file__).resolve().parent
engine = Hybrid(root)
def example(name):
    return json.loads((root/"examples"/f"{name}.json").read_text())

outputs = {name:engine.answer(example(name)) for name in ("celecoxib","process","gap")}
assert outputs["process"]["results"]["size"]["decision"] == "model_estimate"
assert outputs["process"]["results"]["pdi"]["model"]["value"] >= 0
celecoxib = outputs["celecoxib"]["results"]
assert celecoxib["carrier"]["decision"] == "literature_candidate"
assert celecoxib["entrapment"]["model"]["status"] == "withheld"
assert celecoxib["entrapment"]["evidence"][0]["measurements"]["entrapment"]["value"] == 54.4
assert celecoxib["release"]["decision"] == "background_only"
gap = outputs["gap"]["results"]
assert all(item["decision"] in {"background_only","insufficient_evidence"} for item in gap.values())
assert all(doc["id"] != "oral-quercetin" for item in gap.values() for doc in item["evidence"])
bad = example("process")
bad["candidate"]["tfr_ml_min"] = 900
assert engine.answer(bad)["results"]["size"]["model"]["status"] == "out_of_scope"
mismatch = example("process")
mismatch["drug"] = "celecoxib"
assert engine.answer(mismatch)["results"]["size"]["model"]["status"] == "out_of_scope"
assert decide({"status":"process_estimate"},[{"applicability":"background_or_analogue","comparison":"discordant"}])[0] == "conflicting_evidence"
for name, result in outputs.items():
    (root/"examples"/f"{name}_result.json").write_text(json.dumps(result,indent=2)+"\n")
print("Passed process inference, study-specific retrieval, unsupported release, route mismatch, out-of-range rejection, and conflict routing.")
