# SmartNanoFormulator hybrid prototype

The prototype runs locally with the included fitted models. It retrieves
curated source summaries from `evidence.json`, ranks them with TF-IDF and
filters by endpoint and context, then assembles a cited report. This is an
extractive RAG implementation with deterministic arbitration. It does not call
an LLM or learn from text during inference.

## Run

Use Python 3.14 and the supplied dependencies.

```sh
python -m pip install -r requirements.txt
python hybrid.py examples/process.json
python hybrid.py examples/celecoxib.json --json
python hybrid.py examples/gap.json
python check_hybrid.py
```

Only load trusted joblib files. Results are for formulation research.

## Arbitration

Each requested field gets a model assessment and a literature assessment.
The returned JSON records the individual reports, applicability, decision,
confidence basis and rationale. Evidence grades communicate support and scope.
There is no combined probability and a source's keyword similarity is never
treated as scientific confidence.

- Eugster process estimates require supported lipid/chip and numeric ranges.
  Size and PDI require a formation score of at least 0.5. Observed settings
  and within-range extrapolations across settings are identified separately.
  Grouped CV error is a historical error summary, not an interval.
- Drug-loaded and Smart Microfluidics numerical claims are withheld because
  their held-out errors did not demonstrate an MAE advantage over the median.
  The corresponding fitted artifacts and original evaluations are included.
- Direct published measurements stay tied to their batch and citation.
  Analogues and book or regulatory guidance explain options and missing
  evidence. They do not replace missing experimental measurements.
- A conflict requires a reviewed independent measurement, matching candidate
  settings and assay, common units, and a difference exceeding the grouped CV
  absolute-error 90th percentile. Such a conflict is flagged for review. The
  conflict branch was smoke-tested using a simulated claim; no independent
  matched model-validation measurement has been added to the starter corpus.

## Corpus and scale-up

The starter index includes nine curated records. It covers liposomes,
niosomes, transfersomes, ethosomes and phytosomes with different evidence depth.
The sources include an open book chapter, a pharmacopeial chapter, regulatory
guidance and studies. Add reviewed cards with stable IDs, citations, known
drug form, route, tissue, assay, units and batch where available. Set
`independently_verified` only after checking the measurement and training
overlap. An example matching the training corpus gives context, not independent
confirmation. Benefits of the hybrid layer require prospective evaluation on
held-out drug/route tasks with expert-checked citations, appropriate
abstention, and measured formulation outcomes for ranked candidates.
