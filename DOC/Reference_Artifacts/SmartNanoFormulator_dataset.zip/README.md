# SmartNanoFormulator merged research dataset

This release covers 161 unique formulation records, 275 release-assay records,
42 observed release points and all five requested carrier categories. It has
23 literature-curated records and 138 liposome records from the Yanes backend
CSV. Records use source-scoped IDs. Cross-source duplicate matching remains
open where primary-study metadata is missing.

| File | Row unit | Join key |
|---|---|---|
| formulations.csv | One historical formulation per source | batch_id |
| components.csv | One published lipid-phase ingredient | batch_id |
| release_assays.csv | One in vitro assay | assay_id, with batch_id as a foreign key |
| release_points.csv | One assay and time point | assay_id and time_h |
| coverage.csv | One requested field | field |

## How the data fits the platform

The user request supplies drug identity or descriptors, intended route and
target tissue, and a desired release profile (time in hours and percentage
released, with tolerances and a specified assay). The measured release
profile belongs in the release tables. The desired profile is set when the
user submits a design request.

Historical carrier and composition fields describe candidates. Measured
size (nm), PDI (dimensionless), zeta potential (mV), entrapment efficiency
(%), and release (%) provide model targets. An optimizer would propose and
rank new batches against the requested outcome. A paper's chosen carrier
provides a historical category and needs matched outcomes to establish
whether it is the best option for a particular design.

## Source and validation notes

- Yanes et al. (2025), https://doi.org/10.1016/j.ijpx.2025.100393. Public
  backend export at https://github.com/danielyanes22/nanomed_IVR_data.
  Consolidated repeated assays by source formulation ID after checking
  agreement of nonblank formulation fields. The retrieved export lacks
  full compositions, curve points, and primary-study IDs. Reported drug
  loading is kept separately from entrapment efficiency. Exploratory
  summaries may use these records. Study-held-out validation requires the
  original study IDs. Formulations fall under a shared source namespace.
- Bragagni et al., https://doi.org/10.3109/10717544.2012.724472,
  Tables 1 and 2, celecoxib. Component rows preserve the published
  lipid-phase concentrations. This is a partial ingredient list. Batch E
  has no reported EE value in the table.
- https://pmc.ncbi.nlm.nih.gov/articles/PMC9196814/, fusidic acid.
  Tables 1 and 2 plus the highest EE reported in the text. The remaining
  EE values require extraction from the figure. Ratios are from Table 1.
- https://pmc.ncbi.nlm.nih.gov/articles/PMC13212556/, quercetin.
  Tables 1–3. The original category herbosome is preserved and mapped to
  phytosome. The article uses inconsistent cholesterol ratio bases, so
  the reported values are kept in text and flagged.
- https://pmc.ncbi.nlm.nih.gov/articles/PMC10456281/, quercetin.
  The four HSPC liposome rows from Table 3 at time zero.
- Molecular properties are sourced on individual rows. LogP methods differ.
  Solubility measurements with different or unavailable pH and temperature
  should retain their original conditions. The only API stability entry is
  a qualitative celecoxib storage annotation.

Blank fields represent unavailable values or user-defined targets. The
coverage counts are row counts, so a repeated descriptor counts once per
formulation. The merged release is still sparse in exact ingredient ratios,
entrapment efficiency, measured tissue delivery, and head-to-head carrier
comparisons. It does not establish generalization across carriers. To extend
coverage, obtain the full Nottingham SQLite release and LipoDB-BBB archive,
crosswalk original study and batch IDs, and curate comparable batches across
the underrepresented carrier types.
