"""Apply a bundled SmartNanoFormulator model to a CSV of candidate inputs."""
import argparse
import csv
from pathlib import Path

import joblib
import numpy as np


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model", type=Path)
    parser.add_argument("candidates", type=Path)
    args = parser.parse_args()
    bundle = joblib.load(args.model)
    with args.candidates.open(newline="") as handle:
        reader = csv.DictReader(handle)
        fields = bundle["inputs"]
        missing = set(fields).difference(reader.fieldnames or [])
        if missing:
            parser.error("Missing inputs: " + ", ".join(sorted(missing)))
        rows = list(reader)
    if not rows:
        parser.error("The candidate file is empty.")
    if any(not row[field].strip() for row in rows for field in fields):
        parser.error("Every model input must have a value.")
    x = np.array([[row[key] for key in fields] for row in rows], dtype=object)
    estimator = bundle["estimator"]
    if bundle["target"] == "formation_screen_pass":
        result = estimator.predict_proba(x)[:, 1]
        print("row,formation_screen_probability")
    else:
        result = estimator.predict(x)
        print(f"row,predicted_{bundle['target']}")
    for index, value in enumerate(result, start=1):
        print(f"{index},{value:.8g}")


if __name__ == "__main__":
    main()
