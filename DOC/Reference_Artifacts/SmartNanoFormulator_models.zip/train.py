"""Train source-specific models using the Process Training sheet."""
import argparse
import csv
import json
from pathlib import Path

import joblib
import numpy as np
from openpyxl import load_workbook
from sklearn.compose import ColumnTransformer, TransformedTargetRegressor
from sklearn.dummy import DummyRegressor
from sklearn.ensemble import ExtraTreesRegressor, RandomForestRegressor, ExtraTreesClassifier
from sklearn.linear_model import Ridge
from sklearn.metrics import average_precision_score, balanced_accuracy_score, f1_score, roc_auc_score
from sklearn.model_selection import GroupKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from xgboost import XGBRegressor


SPECS = {
    "eugster": ("formation_pass", ["cholesterol_pct","peg_pct","tfr_ml_min","aqueous_to_organic_frr"], ["primary_lipid","chip"]),
    "smart_microfluidics": ("development", ["esm_mg_ml","hspc_mg_ml","cholesterol_mg_ml","dspe_peg2000_mg_ml","tfr_ml_min","aqueous_to_organic_frr"], ["aqueous_medium"]),
}


def read_rows(path):
    workbook = load_workbook(path, read_only=True, data_only=True)
    headers, *records = workbook["Process Training"].values
    workbook.close()
    return [dict(zip(headers, row)) for row in records]


def matrix(rows, fields):
    return np.array([[row[key] for key in fields] for row in rows], dtype=object)


def preprocessing(n_numeric, n_categorical):
    return ColumnTransformer([
        ("numeric", StandardScaler(), list(range(n_numeric))),
        ("category", OneHotEncoder(handle_unknown="ignore", sparse_output=False), list(range(n_numeric, n_numeric + n_categorical))),
    ])


def model(name, n_numeric, n_categorical):
    estimator_name = name.removesuffix("_log")
    if estimator_name == "median":
        estimator = DummyRegressor(strategy="median")
    elif estimator_name == "ridge":
        estimator = Ridge(alpha=1.0)
    elif estimator_name.startswith("extra"):
        leaf = int(estimator_name[-1])
        estimator = ExtraTreesRegressor(n_estimators=180, min_samples_leaf=leaf, random_state=42, n_jobs=2)
    elif estimator_name == "forest":
        estimator = RandomForestRegressor(n_estimators=180, min_samples_leaf=2, random_state=42, n_jobs=2)
    else:
        depth = int(estimator_name[-1])
        estimator = XGBRegressor(n_estimators=260, max_depth=depth, learning_rate=0.045,
                                 subsample=0.85, colsample_bytree=0.9, n_jobs=2, random_state=42)
    if name.endswith("_log"):
        estimator = TransformedTargetRegressor(regressor=estimator, func=np.log1p, inverse_func=np.expm1)
    return make_pipeline(preprocessing(n_numeric,n_categorical), estimator)


def regression_scores(y,p):
    residual = y-p
    return {"mae":float(np.abs(residual).mean()),"rmse":float(np.sqrt(np.mean(residual**2))),
            "r2":float(1-np.sum(residual**2)/np.sum((y-y.mean())**2))}


def write_csv(path, rows):
    with path.open("w", newline="") as file:
        writer=csv.DictWriter(file,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def regression(rows, name, spec, target, output):
    role,num,cat=spec
    selected=[r for r in rows if r["role"]==role]
    fields=num+cat
    x=matrix(selected,fields)
    y=np.array([r[target] for r in selected],dtype=float)
    groups=np.array([r["settings_group"] for r in selected])
    folds=np.array([r["fold"] for r in selected])
    candidates=["ridge","extra1","extra3","forest","xgb2","xgb4"]
    if target=="size_nm":
        candidates += ["extra1_log","extra3_log","xgb2_log","xgb4_log"]
    dimensions=(len(num),len(cat))

    def select(ids):
        splitter=GroupKFold(n_splits=3)
        splits=list(splitter.split(x[ids],y[ids],groups[ids]))
        scores={}
        for candidate in candidates:
            errors=[]
            for tr,va in splits:
                estimator=model(candidate,*dimensions)
                estimator.fit(x[ids[tr]],y[ids[tr]])
                prediction=estimator.predict(x[ids[va]])
                errors.extend(np.abs(y[ids[va]]-prediction))
            scores[candidate]=float(np.mean(errors))
        return min(scores,key=scores.get),scores

    out_of_fold={key:np.zeros(len(y)) for key in ("selected","median","ridge")}
    choices=[]
    for fold in sorted(set(folds)):
        train=np.flatnonzero(folds!=fold)
        test=np.flatnonzero(folds==fold)
        assert not set(groups[train])&set(groups[test])
        choice,_=select(train)
        choices.append({"fold":int(fold),"model":choice})
        for key,algorithm in (("selected",choice),("median","median"),("ridge","ridge")):
            estimator=model(algorithm,*dimensions).fit(x[train],y[train])
            out_of_fold[key][test]=estimator.predict(x[test])

    final,ranking=select(np.arange(len(y)))
    fitted=model(final,*dimensions).fit(x,y)
    model_path=output/f"{name}_{target}.joblib"
    joblib.dump({"estimator":fitted,"inputs":fields,"target":target,"algorithm":final},model_path)
    report={"cohort":name,"target":target,"development_n":len(y),"outer_choices":choices,
            "final_algorithm":final,"final_inner_mae":ranking,
            "grouped_nested_cv":{key:regression_scores(y,p) for key,p in out_of_fold.items()}}
    predictions=[{"batch_id":r["batch_id"],"group":r["settings_group"],"fold":r["fold"],
                  "actual":v,"selected_prediction":p,"median_prediction":b,"ridge_prediction":q}
                 for r,v,p,b,q in zip(selected,y,*out_of_fold.values())]
    write_csv(output/f"{name}_{target}_grouped_predictions.csv",predictions)

    if name=="smart_microfluidics":
        held=[r for r in rows if r["role"]=="external_validation"]
        assert not set(groups)&{r["settings_group"] for r in held}
        hx=matrix(held,fields)
        hy=np.array([r[target] for r in held],dtype=float)
        hp=fitted.predict(hx)
        median=model("median",*dimensions).fit(x,y).predict(hx)
        ridge=model("ridge",*dimensions).fit(x,y).predict(hx)
        report["wet_lab_holdout"]={"n":len(hy),"selected":regression_scores(hy,hp),
                                  "median":regression_scores(hy,median),"ridge":regression_scores(hy,ridge)}
        write_csv(output/f"{name}_{target}_holdout_predictions.csv",
                  [{"batch_id":r["batch_id"],"actual":v,"selected_prediction":p,
                    "median_prediction":b,"ridge_prediction":q} for r,v,p,b,q in zip(held,hy,hp,median,ridge)])
    return report


def formation(rows, output):
    _,num,cat=SPECS["eugster"]
    fields=num+cat
    rows=[r for r in rows if r["role"] in {"formation_pass","formation_screen_only"} and r["formation_screen_pass"] is not None]
    x=matrix(rows,fields)
    y=np.array([r["formation_screen_pass"] for r in rows],dtype=int)
    folds=np.array([r["fold"] for r in rows])
    groups=np.array([r["settings_group"] for r in rows])
    probability=np.zeros(len(y))
    estimator=make_pipeline(preprocessing(len(num),len(cat)),
                            ExtraTreesClassifier(n_estimators=250,min_samples_leaf=2,random_state=42,n_jobs=2))
    for fold in sorted(set(folds)):
        train,test=folds!=fold,folds==fold
        assert not set(groups[train])&set(groups[test])
        estimator.fit(x[train],y[train])
        probability[test]=estimator.predict_proba(x[test])[:,1]
    labels=probability>=0.5
    estimator.fit(x,y)
    joblib.dump({"estimator":estimator,"inputs":fields,"target":"formation_screen_pass"},output/"eugster_formation.joblib")
    write_csv(output/"eugster_formation_grouped_predictions.csv",
              [{"batch_id":r["batch_id"],"group":r["settings_group"],"fold":r["fold"],"actual":v,"probability":p}
               for r,v,p in zip(rows,y,probability)])
    return {"n":len(y),"positive":int(y.sum()),"balanced_accuracy":balanced_accuracy_score(y,labels),
            "f1":f1_score(y,labels),"roc_auc":roc_auc_score(y,probability),
            "average_precision":average_precision_score(y,probability)}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("workbook",type=Path)
    parser.add_argument("output",type=Path)
    args=parser.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    rows=read_rows(args.workbook)
    results={"regression":[]}
    for name,spec in SPECS.items():
        for target in ("size_nm","pdi"):
            result=regression(rows,name,spec,target,args.output)
            results["regression"].append(result)
            print(name,target,result["grouped_nested_cv"]["selected"],flush=True)
    results["formation"]=formation(rows,args.output)
    (args.output/"results.json").write_text(json.dumps(results,indent=2))


if __name__=="__main__":
    main()
