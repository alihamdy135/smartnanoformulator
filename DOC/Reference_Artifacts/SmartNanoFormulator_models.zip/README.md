# SmartNanoFormulator model benchmark

## Run the models

Use Python 3.14 with the versions in requirements.txt.

```sh
python -m pip install -r requirements.txt
python predict.py eugster_size_nm.joblib eugster_example.csv
python predict.py eugster_formation.joblib eugster_example.csv
python train.py /path/to/SmartNanoFormulator_research.xlsx retrained
```

The workbook's Process Training sheet supplies the cohort roles, grouping
keys and outer folds. The joblib files include the fitted model, ordered
input columns and target. The two Smart Microfluidics regressors are
benchmarks. Their selected models underperformed the median in holdout MAE.
For the Eugster model, size and PDI estimates are conditional on passing the
formation screen. Formation probability is a model score without calibration.

The size target is in nm. PDI is dimensionless. Eugster inputs include lipid
and chip identifiers, cholesterol and PEG percentages, total flow (mL/min)
and aqueous/organic flow ratio. Smart Microfluidics inputs include ESM, HSPC,
cholesterol and DSPE-PEG2000 concentrations (mg/mL), total flow, aqueous/organic
flow ratio, and medium. The training sources define the available design spaces.

## Evaluation

Regression models were selected by MAE in three-fold grouped cross-validation
inside each of five fixed outer folds. Median and ridge were evaluated on the
same outer folds. The final model for each target was selected using all
development data, then refit on that data. The 12 Smart Microfluidics wet-lab
rows were used only for evaluation. The Eugster classifier uses grouped
out-of-fold probabilities at a fixed threshold of 0.5. The screen label uses
population, measured size and PDI. These measurements were omitted from its
inputs. No synthetic samples were used. Exact settings, rather than unseen
studies, define the group splits. This study reuses published data.

## External context

- Eugster et al. (2024), https://doi.org/10.1016/j.jconrel.2024.10.065.
  The same source study reported size R² of approximately 0.74 under
  10-fold CV. Our pooled grouped CV R² is 0.740 with a different split
  protocol. This is a comparable magnitude, not evidence of superiority.
- Buttitta et al. (2025), https://doi.org/10.1016/j.ijpharm.2025.126362.
  Table 4 reports wet-lab MAEs of 74.814 nm and 0.0841 PDI for a mixture
  of experts. Our selected models achieve 255.631 nm and 0.1949 on the
  related 12-row public holdout. The training pipelines and splits differ.
- Ye et al. (2023), https://doi.org/10.1016/j.ajps.2023.100811.
  Separate drug-loaded liposome data, reported test MAE of 42.30 nm for size,
  0.04 for PDI, 9.62 mV for zeta potential and 15.53 percentage points for
  encapsulation using Random Forest (LightGBM had MAE 15.35 for encapsulation).
  These numbers describe different samples, inputs and evaluation protocols.

## Research scope

The models address the liposome process stage, predicting formation screening,
size and PDI from composition and preparation. The candidate differentiator
for the full proposal is cross-carrier inverse design conditioned on a drug,
route, tissue and desired release. Forward quality prediction and inverse
liposome design already have published precedents. Establish the broader
contribution with matched cross-carrier experiments, drug- and study-held-out
testing, and a prospective comparison against nearest literature formulations
and a fixed-carrier optimizer under the same experimental budget. A relevant
endpoint is the fraction of top-ranked batches meeting all prespecified
quality and release criteria in the lab. Tissue-targeting claims require
measured delivery outcomes.
