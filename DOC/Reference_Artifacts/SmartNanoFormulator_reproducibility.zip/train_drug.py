"""Endpoint-specific models for drug-loaded formulations with grouped evaluation."""
import argparse
import csv
import json
from pathlib import Path

import joblib
import numpy as np
from sklearn.compose import ColumnTransformer, TransformedTargetRegressor
from sklearn.dummy import DummyRegressor
from sklearn.ensemble import ExtraTreesRegressor, HistGradientBoostingRegressor, RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.linear_model import Ridge
from sklearn.model_selection import GroupKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from preprocess import CATEGORICAL, ENDPOINTS, NUMERIC, write

# Ratio slots have different excipient meanings across papers.
NUMERIC=tuple(k for k in NUMERIC if not k.startswith("ratio_part_"))
FEATURES=NUMERIC+CATEGORICAL
CANDIDATES=("median","ridge","extra","forest","boost")


def inputs(rows):
    return np.array([[float(r[k]) if r[k] else np.nan for k in NUMERIC]+
                     [r[k] or "unreported" for k in CATEGORICAL] for r in rows],dtype=object)


def estimator(name,target):
    methods={
        "median":DummyRegressor(strategy="median"),
        "ridge":Ridge(alpha=10),
        "extra":ExtraTreesRegressor(n_estimators=100,min_samples_leaf=3,random_state=42,n_jobs=2),
        "forest":RandomForestRegressor(n_estimators=100,min_samples_leaf=3,random_state=42,n_jobs=2),
        "boost":HistGradientBoostingRegressor(max_iter=90,max_leaf_nodes=12,min_samples_leaf=10,random_state=42),
    }
    pre=ColumnTransformer([
        ("numeric",make_pipeline(SimpleImputer(strategy="median",add_indicator=True,keep_empty_features=True),StandardScaler()),list(range(len(NUMERIC)))),
        ("categorical",OneHotEncoder(handle_unknown="ignore",sparse_output=False),list(range(len(NUMERIC),len(FEATURES)))),
    ])
    model=methods[name]
    if target=="size_nm":
        model=TransformedTargetRegressor(regressor=model,func=np.log1p,inverse_func=np.expm1)
    return make_pipeline(pre,model)


def predict(model,x,target):
    bounds={"size_nm":(0,np.inf),"pdi":(0,1),"ee_pct":(0,100),"observed_release_24h_pct":(0,100)}
    return np.clip(model.predict(x),*bounds.get(target,(-np.inf,np.inf)))


def metrics(y,p):
    e=y-p
    return dict(mae=float(np.abs(e).mean()),rmse=float(np.sqrt(np.mean(e**2))),
                r2=float(1-np.sum(e**2)/np.sum((y-y.mean())**2)))


def evaluate(rows,target,group_col,output,save):
    x=inputs(rows)
    y=np.array([float(r[target]) for r in rows])
    groups=np.array([r[group_col] for r in rows])
    def choose(indices):
        parts=list(GroupKFold(n_splits=3).split(x[indices],y[indices],groups[indices]))
        losses={}
        for name in CANDIDATES:
            residual=[]
            for train,test in parts:
                a,b=indices[train],indices[test]
                fitted=estimator(name,target).fit(x[a],y[a])
                residual.extend(np.abs(y[b]-predict(fitted,x[b],target)))
            losses[name]=float(np.mean(residual))
        return min(losses,key=losses.get)

    oof=np.empty(len(y))
    baseline=np.empty(len(y))
    fold_ids=np.zeros(len(y),dtype=int)
    selected={}
    for fold,(a,b) in enumerate(GroupKFold(n_splits=5).split(x,y,groups),1):
        assert not set(groups[a])&set(groups[b])
        chosen=choose(a)
        selected[fold]=chosen
        oof[b]=predict(estimator(chosen,target).fit(x[a],y[a]),x[b],target)
        baseline[b]=np.median(y[a])
        fold_ids[b]=fold
    predictions=[dict(batch_id=r["batch_id"],target=target,grouping=group_col,group=groups[i],
        fold=int(fold_ids[i]),actual=y[i],prediction=oof[i],median=baseline[i],
        algorithm=selected[int(fold_ids[i])]) for i,r in enumerate(rows)]
    final=None
    if save:
        final=choose(np.arange(len(y)))
        fitted=estimator(final,target).fit(x,y)
        joblib.dump(dict(estimator=fitted,target=target,inputs=FEATURES,algorithm=final),
                    output/f"drug_{target}.joblib",compress=3)
    return dict(target=target,grouping=group_col,n=len(y),groups=len(set(groups)),
                **metrics(y,oof),median_mae=metrics(y,baseline)["mae"],final_model=final),predictions


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("directory",type=Path)
    args=parser.parse_args()
    with (args.directory/"drug_training.csv").open(encoding="utf-8") as file:
        rows=list(csv.DictReader(file))
    reports,predictions=[],[]
    for target in ENDPOINTS:
        eligible=[r for r in rows if r[target]!=""]
        for group in ("source_study_id","drug_group"):
            report,part=evaluate(eligible,target,group,args.directory,group=="source_study_id")
            reports.append(report)
            predictions.extend(part)
            print(report,flush=True)
    write(args.directory/"drug_metrics.csv",reports)
    write(args.directory/"drug_oof_predictions.csv",predictions)
    (args.directory/"drug_features.json").write_text(json.dumps(FEATURES,indent=2))


if __name__=="__main__":
    main()
