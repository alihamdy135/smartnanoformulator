# SmartNanoFormulator | cleaned dataset and modelling release

## Data files

- `formulations.csv` contains the complete 2,641-record source catalogue with
  preprocessing fields, source identifiers, and citations.
- `drug_training.csv` contains the 685 screened drug-loaded catalogue records.
  There are separate labelled subsets for each endpoint. Join by `batch_id`.
- `process_training.csv` contains 1,695 process runs and their roles, including
  12 experimental holdout runs and 5 development rows with overlapping
  settings excluded from process-model fitting. The 928 Eugster screened
  formulations support conditional size and PDI prediction.
- The release and ingredient tables preserve linked observations. The 21 newly
  parsed 24 h labels are in formulations.csv and drug_training.csv. Release
  curves in release_points.csv remain the previously curated points.
- `coverage.csv` reports values present before and after preprocessing.
- `drug_metrics.csv` and `drug_oof_predictions.csv` document nested grouped
  evaluation. MAE and RMSE are in native units. Size is in nm, zeta in mV,
  PDI is dimensionless, and EE and release are in percentage points.
- `process_results.json` contains the existing process benchmarks. The process
  models were carried forward from the same measured training cohort.

## Reproduce

```sh
python -m pip install -r requirements.txt
python preprocess.py SmartNanoFormulator_research.xlsx regenerated
python train_drug.py regenerated
python train_process.py SmartNanoFormulator_research.xlsx regenerated_process
```

The .joblib files store the fitted estimators and the expected ordered feature
names. Load only model files from trusted sources. Drug model inputs follow
`train_drug.inputs`, including missing numeric values and unreported categories.
Drug and study IDs are grouping identifiers. They are excluded from model
inputs. Median numeric imputation and missingness indicators are fit inside each
training fold. Final estimators are fitted after evaluation. The drug pipeline
selects among median, ridge, Extra Trees, Random Forest and histogram gradient
boosting by inner-fold MAE. Five outer folds are grouped by study or normalized
drug name in two separate evaluations. Synonyms and salt forms may still span
drug-name groups. Neither split guarantees simultaneous drug and study novelty.

## Preprocessing and limitations

Drug descriptors were recovered through exact normalized reported-name matches
to rows with a compound ID and descriptor provenance. These are provisional
annotations, with the donor recorded. Confirm stereochemistry, salt, and
chemical form before a journal deposit. Lipid ingredient indicators represent
mentions in reported composition. A zero means no matching mention. Numeric
ratio slots are preserved for review, with the ratio basis, and excluded from
model inputs because ingredient order varies. The release parser accepts
explicit 24 h time with a single exact numeric result. Source-ambiguous values,
unknown assay conditions, missing route and tissue, and API stability remain
as documented. Outcome labels were never imputed. The new release labels need
primary-paper and assay verification, and the release model pools heterogeneous
conditions as an exploratory benchmark. Some cross-source duplicates may
remain in the catalogue. The drug subset excludes rows without study ID,
drug name, carrier, or composition and collapses matching study signatures.

No catalogue row has every historical field needed for the full proposal.
Desired release is a design request supplied at inference. Carrier and
ingredient composition are candidate inputs. Carrier recommendations would
require matched comparisons and prospective validation. The reported scores
describe endpoint prediction, not improved carrier selection, tissue delivery,
or performance under new assay conditions.

## Sources and redistribution

Preserve row-level sources and citations for publication. Review the source
licenses and spot-check the original papers before releasing a public archive.

- Eugster et al., https://doi.org/10.1016/j.jconrel.2024.10.065
- Lavagna et al., https://doi.org/10.1016/j.dib.2026.112667
- Mali, Thorat and Syed, LipoDB-BBB v1.0,
  https://doi.org/10.5281/zenodo.19677556 (CC BY 4.0).
  Adapted by filtering and mapping to the catalogue schema.
- Yanes et al., https://doi.org/10.1016/j.ijpx.2025.100393
