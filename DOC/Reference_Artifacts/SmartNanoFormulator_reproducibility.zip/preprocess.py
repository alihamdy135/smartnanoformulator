"""Build the cleaned catalogue and modelling cohorts from the research workbook."""
import argparse
import csv
import re
from pathlib import Path

from openpyxl import load_workbook

ENDPOINTS=("size_nm","pdi","zeta_mv","ee_pct","observed_release_24h_pct")
DESCRIPTORS=("mw_da","logp","pka","solubility_mg_ml")
INGREDIENTS={
    "has_cholesterol":r"\bcholesterol\b|\bchol\b",
    "has_peg_lipid":r"dspe.?(?:m)?peg|pegylated lipid",
    "has_phosphatidylcholine":r"phosphatidylcholine|lecithin|\b(?:hspc|dppc|dspc|dopc|popc|dmpc|epc)\b",
    "has_nonionic_surfactant":r"\b(?:tween|span|polysorbate|poloxamer)\b",
    "has_cationic_lipid":r"\b(?:dotap|dotma|ddab)\b|stearylamine",
    "has_ethyl_alcohol":r"ethanol|ethyl alcohol",
}
NUMERIC=(*DESCRIPTORS,*INGREDIENTS,"drug_to_lipid_number","n_ratio_parts",
         "ratio_part_1_share","ratio_part_2_share","ratio_part_3_share","ratio_part_4_share")
CATEGORICAL=("carrier_type","preparation_category","ratio_basis","logp_method","route_intended","target_tissue_intended")


def key(value):
    return " ".join(str(value or "").casefold().strip().split())


def read_sheet(book,name):
    header,*data=book[name].values
    return [dict(zip(header,row)) for row in data]


def write(path,rows):
    fields=list(dict.fromkeys(k for r in rows for k in r))
    with path.open("w",encoding="utf-8",newline="") as file:
        writer=csv.DictWriter(file,fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def preparation(value):
    value=key(value)
    rules=(
        ("microfluidic",r"microfluid"),
        ("thin_film_hydration",r"thin.film|film hydration"),
        ("reverse_phase_evaporation",r"reverse.phase|reversed.phase"),
        ("ethanol_injection",r"ethanol injection"),
        ("solvent_injection",r"solvent injection|antisolvent"),
        ("dehydration_rehydration",r"dehydration.rehydration"),
    )
    return next((name for name,pattern in rules if re.search(pattern,value)),None)


def ratios(value,basis):
    if not value or not basis:
        return ()
    tail=str(value).rsplit("ratio=",1)[-1].strip()
    match=re.fullmatch(r"(\d+(?:\.\d+)?(?:\s*:\s*\d+(?:\.\d+)?){1,3})\s*(?:\([^()]*\))?",tail)
    if not match:
        return ()
    numbers=[float(x) for x in match[1].split(":")]
    if sum(numbers)==0:
        return ()
    return tuple(x/sum(numbers) for x in numbers)


def release_value(row):
    if row["observed_release_24h_pct"] is not None:
        return row["observed_release_24h_pct"],"curated_numeric"
    if not re.fullmatch(r"24(?:\.0)?(?:\s*h(?:ours?)?)?",key(row["release_time_reported"])):
        return None,None
    value=str(row["release_reported"] or "").strip()
    match=re.fullmatch(r"(\d+(?:\.\d+)?)\s*%?(?:\s*±\s*\d+(?:\.\d+)?\s*%?)?",value)
    if match and (1<float(match[1])<=100 or "%" in value and 0<=float(match[1])<=100):
        return float(match[1]),"parsed_curated_24h"
    return None,None


def main():
    p=argparse.ArgumentParser()
    p.add_argument("workbook",type=Path)
    p.add_argument("output",type=Path)
    args=p.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    book=load_workbook(args.workbook,read_only=True,data_only=True)
    rows=read_sheet(book,"Source Archive")
    original={k:sum(r[k] is not None for r in rows) for k in (*DESCRIPTORS,*ENDPOINTS)}
    donors={}
    for row in rows:
        if row["drug_name"] and all(row[k] for k in ("drug_id","descriptor_source")):
            donors.setdefault(key(row["drug_name"]),row.copy())
    for row in rows:
        k=key(row["drug_name"])
        donor=donors.get(k)
        row["descriptor_donor_batch"]=None
        if donor and any(row[f] is None and donor[f] is not None for f in DESCRIPTORS):
            row["descriptor_donor_batch"]=donor["batch_id"]
            for f in DESCRIPTORS:
                if row[f] is None:
                    row[f]=donor[f]
                    if f=="logp" and donor[f] is not None:
                        row["logp_method"]=donor["logp_method"]
            row["descriptor_source"]=row["descriptor_source"] or donor["descriptor_source"]
            row["pka_source"]=row["pka_source"] or donor["pka_source"]
            row["additional_descriptor_source"]=row["additional_descriptor_source"] or donor["additional_descriptor_source"]
            row["solubility_temperature_c"]=row["solubility_temperature_c"] or donor["solubility_temperature_c"]
        row["drug_group"]=k or None
        row["preparation_category"]=preparation(row["method"])
        basis=key(row["composition_basis"])
        row["ratio_basis"]=("molar" if re.search(r"mol|molar",basis)
                           else "mass" if re.search(r"w/w|weight|mass|^mg",basis) else None)
        composition=row["reported_composition"]
        for field,pattern in INGREDIENTS.items():
            row[field]=int(bool(re.search(pattern,composition,re.I))) if composition else None
        shares=ratios(composition,row["ratio_basis"])
        row["n_ratio_parts"]=len(shares) or None
        for i in range(4):
            row[f"ratio_part_{i+1}_share"]=shares[i] if i<len(shares) else None
        mass=key(row["drug_to_lipid_reported"])
        # A bare number lacks the ratio denominator/basis and is retained only as raw text.
        pair=re.fullmatch(r"(\d+(?:\.\d+)?):(\d+(?:\.\d+)?)",mass)
        row["drug_to_lipid_number"]=float(pair[1])/float(pair[2]) if pair and float(pair[2])>0 else None
        row["observed_release_24h_pct"],row["release_24h_provenance"]=release_value(row)
        has_proposal_inputs=all(row.get(f) is not None for f in (*DESCRIPTORS,"api_stability","route_intended","target_tissue_intended","reported_composition"))
        row["all_proposal_historical_fields"]=int(has_proposal_inputs and all(row[f] is not None for f in ENDPOINTS))
    # Restrict drug models to sourced, drug-loaded records with composition.
    drug=[r for r in rows if all(r.get(f) for f in ("drug_group","source_study_id","reported_composition","carrier_type"))]
    # Same paper and same payload/composition/measurements can appear twice under separate catalogue IDs.
    seen=set()
    for row in drug:
        sig=tuple(key(row[f]) for f in ("source_study_id","drug_group","carrier_type","reported_composition","method",*ENDPOINTS))
        row["model_eligible"]=int(sig not in seen)
        seen.add(sig)
    drug=[r for r in drug if r["model_eligible"]]
    write(args.output/"formulations.csv",rows)
    write(args.output/"drug_training.csv",drug)
    for name in ("Process Training","Ingredients","Release Assays","Release Points"):
        write(args.output/(name.lower().replace(" ","_")+".csv"),read_sheet(book,name))
    audit=[{"field":f,"before":n,"after":sum(r[f] is not None for r in rows)} for f,n in original.items()]
    audit.extend({"field":f,"before":None,"after":sum(r.get(f) is not None for r in rows)}
                 for f in ("preparation_category","n_ratio_parts","drug_to_lipid_number"))
    write(args.output/"coverage.csv",audit)
    print("catalogue",len(rows),"drug cohort",len(drug),"full proposal rows",sum(r["all_proposal_historical_fields"] for r in rows))
    print(audit)
    for f in ENDPOINTS:
        selected=[r for r in drug if r[f] is not None]
        print(f,len(selected),len({r["source_study_id"] for r in selected}),len({r["drug_group"] for r in selected}))


if __name__=="__main__":
    main()
